package dev.hailab.deeppilot.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import dev.hailab.deeppilot.R
import dev.hailab.deeppilot.core.protocol.SkillSummary
import dev.hailab.deeppilot.core.skills.SkillQuery
import dev.hailab.deeppilot.ui.AppType
import dev.hailab.deeppilot.ui.palette
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.coroutineContext

/** 输入器局部状态：查询字符只筛选目录，开菜单、重连与目录失效才重新读取。 */
@Composable
fun SkillSuggestions(
    query: SkillQuery?, catalogScope: String, load: suspend () -> List<SkillSummary>,
    onPick: (SkillSummary) -> Unit, onDismiss: () -> Unit,
) {
    var skills by remember(catalogScope) { mutableStateOf<List<SkillSummary>>(emptyList()) }
    var loading by remember(catalogScope) { mutableStateOf(true) }
    var failed by remember(catalogScope) { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(catalogScope, query?.start, retry) {
        skills = emptyList()
        failed = false
        loading = true
        if (query != null) {
            try {
                val result = load()
                coroutineContext.ensureActive()
                skills = result
            } catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { failed = true }
            finally { loading = false }
        }
    }
    val listState = rememberLazyListState()
    // 改变查询或目录后展示最相关的首项，避免沿用滚动到底部的位置。
    LaunchedEffect(query?.query, skills) { listState.scrollToItem(0) }
    if (query == null) return
    val p = palette
    val matches = query.matches(skills)
    // 两行语义字号加内边距；大字体可少显示几条，描述长度不再改变行高。
    val textHeight = with(LocalDensity.current) { AppType.body.lineHeight.toDp() + AppType.caption.lineHeight.toDp() }
    val rowHeight = maxOf(48.dp, textHeight + 16.dp)
    Column(Modifier.fillMaxWidth().background(p.surface, RoundedCornerShape(16.dp)).padding(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.composer_skills_title), style = AppType.body, color = p.foreground, modifier = Modifier.padding(8.dp))
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.composer_skills_close), style = AppType.body) }
        }
        when {
            loading -> Text(stringResource(R.string.composer_skills_loading), style = AppType.body, color = p.foreground, modifier = Modifier.padding(8.dp))
            failed -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.composer_skills_failed), style = AppType.body, color = p.foreground, modifier = Modifier.weight(1f).padding(8.dp))
                TextButton(onClick = { retry++ }) { Text(stringResource(R.string.composer_skills_retry), style = AppType.body) }
            }
            matches.isEmpty() -> Text(stringResource(if (skills.isEmpty()) R.string.composer_skills_empty else R.string.composer_skills_no_match), style = AppType.body, color = p.foreground, modifier = Modifier.padding(8.dp))
            else -> LazyColumn(Modifier.fillMaxWidth().height(minOf(rowHeight * minOf(matches.size, 3), 220.dp)), state = listState) {
                items(matches, key = { it.name }) { skill ->
                    val description = listOfNotNull(
                        if (!skill.modelInvocable) stringResource(R.string.composer_skills_user_only) else null,
                        skill.description.takeIf { it.isNotBlank() },
                    ).joinToString("：").lineSequence().joinToString(" ") { it.trim() }
                    Column(Modifier.fillMaxWidth().clickable { onPick(skill) }.height(rowHeight).padding(8.dp)) {
                        Text("/" + skill.name, style = AppType.body, color = p.foreground, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        // 省略只影响显示，Text 的无障碍语义仍包含完整描述。
                        if (description.isNotEmpty()) Text(description, style = AppType.caption, color = p.secondary, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
